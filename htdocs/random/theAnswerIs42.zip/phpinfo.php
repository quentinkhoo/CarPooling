
<?php

phpinfo();

?>

<?php
// Include config file
require_once '../config.php';

// Initialize the session
session_start();

// Set the default timezone to use
date_default_timezone_set('Asia/Singapore');
 
// If session variable is not set it will redirect to login page
if(!isset($_SESSION['userid']) || empty($_SESSION['userid']) 
	|| !isset($_SESSION['isadmin']) || empty($_SESSION['isadmin'])) {
  header("location: ../login.php");
  exit;
} else {
	$get_users = "SELECT username, email, phone, fullname, isadmin FROM person";
	$prepare_users = pg_prepare($db, "", $get_users);
	
    if ($prepare_users) {
		$execute_users = pg_execute($db, "", array());
		if (!$execute_users) {
			$users_err = "Something went wrong! Please try again.";
		} else {
			$num_rows = pg_num_rows($execute_users);
			if ($num_rows == 0) {
				$users_err = "There are no advertisements available.";
			}				
		}
	} else {
		$users_err = "SQL statement cannot be prepared :(";
	}
	
	if($_SERVER["REQUEST_METHOD"] == "POST") {

	}
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>All Users</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <style type="text/css">
        body{ font: 14px sans-serif; text-align: center; }
		table, th, td {
			border: 1px solid black;
			border-collapse: collapse;
			table-layout: fixed;
			width: 80px;
		}
		th, td {
			padding: 10px;
		}
		
		input[type="text"] {
 		   width: 150px;
 		   height: 30px;
		}
		
		p {text-align:center;}
		td {text-align:center;}
    </style>
</head>
<body>
    <div class="page-header">
        <h1><b>List of Users</b></h1>
		<table style="width:100%">
		<tr>
			<th><p>Username</p></th>
			<th><p>Email</p></th>
			<th><p>Phone</p></th>
			<th><p>Full Name</p></th>
			<th><p>Administrator</p></th>
			<th><p>Update</p></th>
		</tr>
		<?php echo (!empty($execute_users)) ? $users_err : ''; ?>
		<?php while($row = pg_fetch_assoc($execute_users)) { ?>
			<tr>
			<form action="" method="post">
			<td>
				<div class="form-group" align="center">
                <input type="text" name="username" class="form-control" value="<?php echo $row[username]; ?>">
	            </div>
	        </td>
			<td>
				<div class="form-group" align="center" width="80px">
                <input type="text" name="email" class="form-control" value="<?php echo $row[email]; ?>">
	            </div>
			</td>
			<td>
				<div class="form-group" align="center">
                <input type="text" name="phone" class="form-control" value="<?php echo $row[phone]; ?>">
	            </div>
			</td>
			<td>
				<div class="form-group" align="center">
                <input type="text" name="fullname" class="form-control" value="<?php echo $row[fullname]; ?>">
	            </div>
			</td>
			<td>
				<div class="form-group" align="center">
                <input type="text" name="isadmin" class="form-control" value="<?php echo $row[isadmin]; ?>">
	            </div>
			</td>
			<td>
				<input type="submit" class="btn btn-primary" value="Update" />
			</td>
			</form>
			</tr>
		<?php } ?>
		</table>
		<?php echo date("Y-m-d H:i:s") ?>
    </div>
    <p><a href="adminwelcome.php" class="btn btn-warning">Go Back</a></p>
    <p><a href="logout.php" class="btn btn-danger">Sign Out of Your Account</a></p>
</body>
</html>
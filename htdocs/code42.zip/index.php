<?php
header("location: welcome.php");
?>